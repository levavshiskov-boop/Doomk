"""
PYDOOM — Doom-подобный шутер от первого лица на Python (pygame).
Запуск: pip install pygame && python doom.py

Управление:
  W/S — вперёд/назад A/D — страйф (шаг влево/вправо)
  Мышь или ←/→ — поворот ЛКМ / Пробел — выстрел
  Shift — бег Tab — миникарта
  R — рестарт Esc — выход
"""
import math
import random
import sys

import pygame

# ---------- настройки ----------
W, H = 320, 200 # внутреннее разрешение (ретро-пиксели)
SCALE = 3 # во сколько раз растянуть окно
FPS = 60
TEX = 64

LEVEL = [
    "11111111111111111111",
    "10000000000000000001",
    "10222000000003330001",
    "10200000000000030001",
    "10200001111000030001",
    "10000001001000000001",
    "10000001001000000001",
    "10000000001000222001",
    "11110011111000200001",
    "10000000000000200001",
    "10000000000000000001",
    "10033300011100000001",
    "10030000010000011101",
    "10030000010000010001",
    "10000000000000010001",
    "10000222000000000001",
    "10000200000333000001",
    "10000200000000000001",
    "10000000000000000001",
    "11111111111111111111",
]
N = max(len(r) for r in LEVEL)
GRID = [[int(c) for c in r.ljust(N, "1")] for r in LEVEL]
for i in range(N): # гарантируем рамку из стен
    GRID[0][i] = GRID[-1][i] = 1
for row in GRID:
    row[0] = row[-1] = 1
ROWS = len(GRID)


def is_wall(x, y):
    xi, yi = int(x), int(y)
    if xi < 0 or yi < 0 or xi >= N or yi >= ROWS:
        return True
    return GRID[yi][xi] > 0


def los(x0, y0, x1, y1):
    """Есть ли прямая видимость между точками."""
    d = math.hypot(x1 - x0, y1 - y0)
    steps = int(d / 0.1) + 1
    for i in range(1, steps):
        t = i / steps
        if is_wall(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t):
            return False
    return True


# ---------- процедурные текстуры ----------
def make_textures():
    rnd = random.Random(7)
    texs = {}

    brick = pygame.Surface((TEX, TEX))
    brick.fill((60, 40, 35))
    for row in range(8):
        off = 8 if row % 2 else 0
        for bx in range(-1, 5):
            shade = rnd.randint(-18, 18)
            c = (150 + shade, 55 + shade // 2, 45 + shade // 2)
            pygame.draw.rect(brick, c, (bx * 16 + off + 1, row * 8 + 1, 14, 6))
    texs[1] = brick

    tech = pygame.Surface((TEX, TEX))
    tech.fill((70, 75, 85))
    for i in range(0, TEX, 16):
        pygame.draw.rect(tech, (40, 44, 52), (i, 0, 2, TEX))
        pygame.draw.rect(tech, (40, 44, 52), (0, i, TEX, 2))
    for _ in range(6):
        px, py = rnd.randrange(4, 56), rnd.randrange(4, 56)
        col = rnd.choice([(40, 220, 90), (220, 60, 40), (230, 200, 50)])
        pygame.draw.rect(tech, col, (px, py, 5, 3))
    texs[2] = tech

    stone = pygame.Surface((TEX, TEX))
    stone.fill((105, 105, 100))
    for _ in range(500):
        v = rnd.randint(70, 140)
        stone.set_at((rnd.randrange(TEX), rnd.randrange(TEX)), (v, v, v - 5))
    for _ in range(8):
        pygame.draw.line(stone, (60, 60, 58), (rnd.randrange(TEX), rnd.randrange(TEX)),
                         (rnd.randrange(TEX), rnd.randrange(TEX)))
    texs[3] = stone
    return texs


# ---------- спрайты ----------
def make_imp(dead=False):
    s = pygame.Surface((64, 64), pygame.SRCALPHA)
    if dead:
        pygame.draw.ellipse(s, (110, 40, 30), (6, 50, 52, 12))
        pygame.draw.ellipse(s, (150, 20, 20), (14, 54, 30, 7))
        return s
    pygame.draw.rect(s, (90, 55, 35), (20, 42, 9, 20)) # ноги
    pygame.draw.rect(s, (90, 55, 35), (35, 42, 9, 20))
    pygame.draw.ellipse(s, (150, 80, 45), (14, 18, 36, 32)) # торс
    pygame.draw.rect(s, (130, 70, 40), (6, 22, 9, 22)) # руки
    pygame.draw.rect(s, (130, 70, 40), (49, 22, 9, 22))
    pygame.draw.circle(s, (175, 105, 65), (32, 14), 11) # голова
    pygame.draw.polygon(s, (235, 235, 220), [(23, 8), (19, 0), (27, 5)]) # рога
    pygame.draw.polygon(s, (235, 235, 220), [(41, 8), (45, 0), (37, 5)])
    pygame.draw.circle(s, (255, 230, 40), (28, 13), 2) # глаза
    pygame.draw.circle(s, (255, 230, 40), (36, 13), 2)
    pygame.draw.rect(s, (60, 10, 10), (28, 19, 8, 3)) # пасть
    return s


def make_item(kind):
    s = pygame.Surface((64, 64), pygame.SRCALPHA)
    if kind == "health":
        pygame.draw.rect(s, (235, 235, 235), (8, 8, 48, 48), border_radius=6)
        pygame.draw.rect(s, (210, 30, 30), (26, 14, 12, 36))
        pygame.draw.rect(s, (210, 30, 30), (14, 26, 36, 12))
    else:
        pygame.draw.rect(s, (90, 100, 50), (8, 14, 48, 36), border_radius=4)
        for i in range(4):
            pygame.draw.rect(s, (230, 190, 60), (14 + i * 11, 20, 7, 24))
    return s


class Enemy:
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.hp = 60
        self.alive = True
        self.awake = False
        self.cd = random.uniform(0.5, 1.5)

    def try_move(self, dx, dy):
        r = 0.25
        if not is_wall(self.x + dx + math.copysign(r, dx), self.y):
            self.x += dx
        if not is_wall(self.x, self.y + dy + math.copysign(r, dy)):
            self.y += dy


class Item:
    def __init__(self, x, y, kind):
        self.x, self.y, self.kind = x, y, kind
        self.taken = False


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W * SCALE, H * SCALE))
        pygame.display.set_caption("PYDOOM")
        self.small = pygame.Surface((W, H)).convert()
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("consolas,couriernew,monospace", 22, bold=True)
        self.big = pygame.font.SysFont("consolas,couriernew,monospace", 64, bold=True)
        self.texs = {k: v.convert() for k, v in make_textures().items()}
        self.col_cache = {k: [t.subsurface((x, 0, 1, TEX)) for x in range(TEX)]
                          for k, t in self.texs.items()}
        self.imp = make_imp()
        self.imp_dead = make_imp(True)
        self.item_spr = {"health": make_item("health"), "ammo": make_item("ammo")}
        self.bg = pygame.Surface((W, H)).convert()
        for y in range(H // 2):
            v = 25 + y * 40 // (H // 2)
            pygame.draw.line(self.bg, (v, v - 5, v - 5), (0, y), (W, y))
            f = 30 + y * 50 // (H // 2)
            pygame.draw.line(self.bg, (f, f, f - 8), (0, H - 1 - y), (W, H - 1 - y))
        self.flash_s = pygame.Surface((W * SCALE, H * SCALE), pygame.SRCALPHA)
        self.show_map = True
        pygame.event.set_grab(True)
        pygame.mouse.set_visible(False)
        pygame.mouse.get_rel()
        self.reset()

    def reset(self):
        self.px, self.py = 1.5, 1.5
        self.dx, self.dy = 1.0, 0.0
        self.pl_x, self.pl_y = 0.0, math.tan(math.pi / 6) # плоскость камеры (FOV ~ 60°)
        self.hp, self.ammo, self.kills = 100, 24, 0
        self.shoot_cd = 0.0
        self.kick = 0.0
        self.hurt = 0.0
        self.t = 0.0
        self.moving = False
        self.state = "play"
        free = [(x + 0.5, y + 0.5) for y in range(ROWS) for x in range(N)
                if GRID[y][x] == 0 and math.hypot(x - 1, y - 1) > 6]
        random.shuffle(free)
        self.enemies = [Enemy(*free.pop()) for _ in range(9)]
        self.items = [Item(*free.pop(), "health") for _ in range(4)] + \
                     [Item(*free.pop(), "ammo") for _ in range(5)]

    # ---------- логика ----------
    def rotate(self, a):
        c, s = math.cos(a), math.sin(a)
        self.dx, self.dy = self.dx * c - self.dy * s, self.dx * s + self.dy * c
        self.pl_x, self.pl_y = self.pl_x * c - self.pl_y * s, self.pl_x * s + self.pl_y * c

    def move(self, mx, my):
        r = 0.22
        if not is_wall(self.px + mx + math.copysign(r, mx), self.py):
            self.px += mx
        if not is_wall(self.px, self.py + my + math.copysign(r, my)):
            self.py += my

    def shoot(self):
        if self.ammo <= 0 or self.shoot_cd > 0:
            return
        self.ammo -= 1
        self.shoot_cd = 0.55
        self.kick = 1.0
        for _ in range(6): # дробовик: 6 дробинок
            a = random.uniform(-0.06, 0.06)
            c, s = math.cos(a), math.sin(a)
            fx, fy = self.dx * c - self.dy * s, self.dx * s + self.dy * c
            best, best_d = None, 99
            for e in self.enemies:
                if not e.alive:
                    continue
                ex, ey = e.x - self.px, e.y - self.py
                fwd = ex * fx + ey * fy
                side = abs(ex * fy - ey * fx)
                if 0.2 < fwd < best_d and side < 0.35 and los(self.px, self.py, e.x, e.y):
                    best, best_d = e, fwd
            if best:
                best.hp -= random.randint(10, 18)
                best.awake = True
                if best.hp <= 0 and best.alive:
                    best.alive = False
                    self.kills += 1

    def update(self, dt, keys, mouse_dx):
        self.t += dt
        self.shoot_cd = max(0, self.shoot_cd - dt)
        self.kick = max(0, self.kick - dt * 4)
        self.hurt = max(0, self.hurt - dt)
        if self.state != "play":
            return
        speed = (5.0 if keys[pygame.K_LSHIFT] else 3.0) * dt
        fx = (keys[pygame.K_w] - keys[pygame.K_s])
        sx = (keys[pygame.K_d] - keys[pygame.K_a])
        mx = self.dx * fx + (-self.dy) * sx
        my = self.dy * fx + self.dx * sx
        length = math.hypot(mx, my)
        self.moving = length > 0
        if length:
            self.move(mx / length * speed, my / length * speed)
        turn = (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]) * 2.2 * dt + mouse_dx * 0.0025
        if turn:
            self.rotate(turn)
        if keys[pygame.K_SPACE] or pygame.mouse.get_pressed()[0]:
            self.shoot()

        for it in self.items:
            if not it.taken and math.hypot(it.x - self.px, it.y - self.py) < 0.5:
                if it.kind == "health" and self.hp < 100:
                    self.hp = min(100, self.hp + 25)
                    it.taken = True
                elif it.kind == "ammo":
                    self.ammo += 8
                    it.taken = True

        for e in self.enemies:
            if not e.alive:
                continue
            d = math.hypot(self.px - e.x, self.py - e.y)
            sees = d < 12 and los(e.x, e.y, self.px, self.py)
            if sees:
                e.awake = True
            if not e.awake:
                continue
            if d > 1.6:
                sp = 1.1 * dt / d
                e.try_move((self.px - e.x) * sp, (self.py - e.y) * sp)
            e.cd -= dt
            if e.cd <= 0 and sees and d < 9:
                e.cd = random.uniform(1.0, 1.8)
                if random.random() < 0.55:
                    self.hp -= random.randint(4, 10)
                    self.hurt = 0.25

        if self.hp <= 0:
            self.hp = 0
            self.state = "dead"
        elif self.kills >= len(self.enemies):
            self.state = "win"

    # ---------- рендер ----------
    def render_walls(self, zbuf):
        s = self.small
        for x in range(W):
            cam = 2 * x / W - 1
            rdx = self.dx + self.pl_x * cam
            rdy = self.dy + self.pl_y * cam
            mx, my = int(self.px), int(self.py)
            ddx = abs(1 / rdx) if rdx else 1e30
            ddy = abs(1 / rdy) if rdy else 1e30
            if rdx < 0:
                stx, sdx = -1, (self.px - mx) * ddx
            else:
                stx, sdx = 1, (mx + 1 - self.px) * ddx
            if rdy < 0:
                sty, sdy = -1, (self.py - my) * ddy
            else:
                sty, sdy = 1, (my + 1 - self.py) * ddy
            side = 0
            while True:
                if sdx < sdy:
                    sdx += ddx
                    mx += stx
                    side = 0
                else:
                    sdy += ddy
                    my += sty
                    side = 1
                if GRID[my][mx] > 0:
                    break
            dist = max(0.01, (sdx - ddx) if side == 0 else (sdy - ddy))
            zbuf[x] = dist
            wx = (self.py + dist * rdy) if side == 0 else (self.px + dist * rdx)
            wx -= math.floor(wx)
            tx = int(wx * TEX)
            if (side == 0 and rdx > 0) or (side == 1 and rdy < 0):
                tx = TEX - 1 - tx
            kind = GRID[my][mx]
            col = self.col_cache[kind][tx]
            h = int(H / dist)
            if h > H:
                span = max(1, int(H / h * TEX))
                top = (TEX - span) // 2
                piece = col.subsurface((0, top, 1, span))
                strip = pygame.transform.scale(piece, (1, H))
                y0 = 0
            else:
                strip = pygame.transform.scale(col, (1, max(1, h)))
                y0 = (H - h) // 2
            v = int(255 * max(0.15, 1 - dist / 14))
            if side == 1:
                v = int(v * 0.72)
            strip.fill((v, v, v), special_flags=pygame.BLEND_MULT)
            s.blit(strip, (x, y0))

    def render_sprites(self, zbuf):
        objs = [(e.x, e.y, self.imp if e.alive else self.imp_dead, 1.0)
                for e in self.enemies]
        objs += [(i.x, i.y, self.item_spr[i.kind], 0.4) for i in self.items if not i.taken]
        inv = 1.0 / (self.pl_x * self.dy - self.dx * self.pl_y)
        objs.sort(key=lambda o: -((o[0] - self.px) ** 2 + (o[1] - self.py) ** 2))
        for ox, oy, spr, sc in objs:
            sx, sy = ox - self.px, oy - self.py
            tx = inv * (self.dy * sx - self.dx * sy)
            ty = inv * (-self.pl_y * sx + self.pl_x * sy)
            if ty <= 0.25:
                continue
            screen_x = int(W / 2 * (1 + tx / ty))
            size = int(H / ty * sc)
            if size < 2 or size > 700:
                continue
            left = screen_x - size // 2
            if left >= W or left + size <= 0:
                continue
            y0 = H // 2 + int(H / (2 * ty)) - size
            scaled = pygame.transform.scale(spr, (size, size))
            shade = int(255 * max(0.25, 1 - ty / 14))
            scaled.fill((shade, shade, shade, 255), special_flags=pygame.BLEND_RGBA_MULT)
            for x in range(max(0, left), min(W, left + size)):
                if ty < zbuf[x]:
                    self.small.blit(scaled, (x, y0), (x - left, 0, 1, size))

    def render_weapon(self):
        s = self.small
        bob = math.sin(self.t * 10) * 3 if self.moving else 0
        cx = W // 2 + int(bob)
        cy = H + int(self.kick * 14) - 2
        pygame.draw.polygon(s, (45, 45, 50), [(cx - 12, cy), (cx - 7, cy - 58), (cx + 7, cy - 58), (cx + 12, cy)])
        pygame.draw.rect(s, (20, 20, 22), (cx - 6, cy - 62, 12, 8))
        pygame.draw.rect(s, (110, 70, 40), (cx - 16, cy - 22, 32, 24))
        pygame.draw.rect(s, (80, 80, 88), (cx - 3, cy - 56, 6, 40))
        if self.kick > 0.65:
            pygame.draw.polygon(s, (255, 220, 80), [(cx, cy - 100), (cx - 14, cy - 66), (cx + 14, cy - 66)])
            pygame.draw.polygon(s, (255, 140, 30), [(cx, cy - 88), (cx - 7, cy - 66), (cx + 7, cy - 66)])

    def render_minimap(self):
        cs = 6
        ox, oy = W * SCALE - N * cs - 8, 8
        surf = self.screen
        for y in range(ROWS):
            for x in range(N):
                c = (130, 130, 130) if GRID[y][x] else (25, 25, 25)
                pygame.draw.rect(surf, c, (ox + x * cs, oy + y * cs, cs - 1, cs - 1))
        for e in self.enemies:
            if e.alive:
                pygame.draw.circle(surf, (230, 60, 40), (int(ox + e.x * cs), int(oy + e.y * cs)), 2)
        for i in self.items:
            if not i.taken:
                c = (60, 220, 90) if i.kind == "health" else (230, 200, 60)
                pygame.draw.circle(surf, c, (int(ox + i.x * cs), int(oy + i.y * cs)), 2)
        p = (int(ox + self.px * cs), int(oy + self.py * cs))
        pygame.draw.circle(surf, (80, 160, 255), p, 3)
        pygame.draw.line(surf, (80, 160, 255), p, (p[0] + self.dx * 9, p[1] + self.dy * 9))

    def render(self):
        zbuf = [1e9] * W
        self.small.blit(self.bg, (0, 0))
        self.render_walls(zbuf)
        self.render_sprites(zbuf)
        self.render_weapon()
        pygame.transform.scale(self.small, (W * SCALE, H * SCALE), self.screen)
        sw, sh = W * SCALE, H * SCALE
        pygame.draw.line(self.screen, (255, 255, 255), (sw // 2 - 8, sh // 2), (sw // 2 + 8, sh // 2))
        pygame.draw.line(self.screen, (255, 255, 255), (sw // 2, sh // 2 - 8), (sw // 2, sh // 2 + 8))
        if self.hurt > 0:
            self.flash_s.fill((200, 0, 0, int(160 * self.hurt / 0.25)))
            self.screen.blit(self.flash_s, (0, 0))
        pygame.draw.rect(self.screen, (30, 20, 20), (0, sh - 40, sw, 40))
        hp_col = (80, 230, 90) if self.hp > 50 else (230, 190, 50) if self.hp > 25 else (240, 60, 50)
        for txt, x, col in ((f"HP {self.hp:3d}", 14, hp_col),
                            (f"AMMO {self.ammo:3d}", sw // 2 - 70, (240, 210, 90)),
                            (f"KILLS {self.kills}/{len(self.enemies)}", sw - 190, (230, 230, 230))):
            self.screen.blit(self.font.render(txt, True, col), (x, sh - 32))
        if self.show_map:
            self.render_minimap()
        if self.state != "play":
            msg, col = (("YOU DIED", (220, 30, 30)) if self.state == "dead"
                        else ("LEVEL CLEAR!", (80, 230, 90)))
            t = self.big.render(msg, True, col)
            self.screen.blit(t, (sw // 2 - t.get_width() // 2, sh // 2 - 60))
            t2 = self.font.render("R — заново Esc — выход", True, (240, 240, 240))
            self.screen.blit(t2, (sw // 2 - t2.get_width() // 2, sh // 2 + 20))
        pygame.display.flip()

    def run(self):
        while True:
            dt = min(self.clock.tick(FPS) / 1000, 0.05)
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT or (ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE):
                    pygame.quit()
                    sys.exit()
                if ev.type == pygame.KEYDOWN:
                    if ev.key == pygame.K_r:
                        self.reset()
                    elif ev.key == pygame.K_TAB:
                        self.show_map = not self.show_map
            mdx = pygame.mouse.get_rel()[0]
            self.update(dt, pygame.key.get_pressed(), mdx)
            self.render()


if __name__ == "__main__":
    Game().run()